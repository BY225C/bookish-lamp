#pedirle un numero al usuario
numero= input("dame un numero: ")

#multiplicando el numero po2
resultado= int(numero) * 2 #lo combierte a numero entero el int 

print(resultado)