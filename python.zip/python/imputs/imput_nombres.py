#pedirle un dato al usuario
nombre = input("ingrese su nombre: ")

#muestrame el dato
print(f"tu nombre es: {nombre}") #siempre va ser texto