#se puede crear una lista con list 
lista1 = list(["luis","moina",34])

#devuelve la cantidad de elementos que hay en la lista
cantidad_de_elementod= len(lista1) 

#agrengando elemtos en la lista

lista1.append("programador")#agrega un elemento al fnal de la lista
lista1.insert(1,"ingeniero")#agrega un elemento en la posicion que se le indique
lista1.extend(["python","java"])#agrega varios elementos al final de la lista

#eliminado un elemento de la lista
lista1.pop(0)#elimina el elemento que se le indique y tamien se puede eliminar el ultimo con -1

lista1.remove("moina")#elimina el elemento que se le indique por su valor

#lista1.clear()#elimina todos los elementos de la lista

lista1.sort()#ordena los elementos de la lista pero sin las cadenas de texto
#y si usamos el parametro reverse=True ordena de forma descendente

lista1.reverse()#invierte el orden de los elementos de la lista pero sin ordenarlas

#index 
posicion = lista1.index(34)#devuelve la posicion del elemento que se le indique

print(lista1)