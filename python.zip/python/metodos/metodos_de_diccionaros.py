diccionario = {
    "nombre" : "luis",
    "apellido": "moina",
    "edad" : 15
}

claves = diccionario.keys() #devuelve las claves del diccionario
 
claves1 = diccionario.get("nombre") #devuelve el valor de la clave y no coloca error si no exite clave

#eliminar todo lo del diccionario
#diccionario.clear()
#eliminar un elemento del diccionario
diccionario.pop("edad")#y se puede eliminar varios elementos

#obteniendo un elemento del diccionario
diccionario_iterable = diccionario.items() # ve todos los items del diccionario

print(diccionario_iterable)