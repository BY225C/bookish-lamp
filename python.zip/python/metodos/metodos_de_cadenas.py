#-----------------------------------------
#Los Metodos de Cadens de python 
#-----------------------------------------
#los metodos se colocan despues del punto de la variable

cadena1 = "hola mundo"
cadena2 = "hola luis"

#metodo dir
print(dir(cadena1))#muestra todos los metodos disponibles para las cadenas


#metodo upper

resultado = cadena1.upper()#convierte la cadena a mayusculas

#metodo lower

resultado2 = cadena1.lower()#convierte la cadena a minusculas

#metodo capitalize

resultado3 = cadena1.capitalize()#convierte la primera letra en mayuscula

#metodo find

resultado4 = cadena1.find("mundo")#busca una subcadena y devuelve la posicion 
#si no la encuentra devuelve -1
#print(resultado4) devuelve 1

#metodo index

resultado5 = cadena1.index("mundo")#busca una subcadena y devuelve la posicion
#si no la encuentra lanza un error
#print(resultado5) devuelve 1

#metodo isnumeric

es_numerico = cadena1.isnumeric()#devuelve True si la cadena es numerica
#print(es_numerico) devuelve False

#metodo isalpha

es_alfabetico = cadena1.isalpha()#devuelve True si la cadena es alfabetica
#print(es_alfabetico) devuelve False ya que contiene un espacio y es un caracter especial

#metodo caount

cantidad_o = cadena1.count("o")#cuenta cuantas veces aparece un caracter 
#print(cantidad_o) devuelve 2 ya que hay dos o en la cadena

#funcion len

longitud = len(cadena1)#devuelve la cantidad de caracteres de la cadena

#metodo startswith

comienza_con_hola = cadena1.startswith("hola")#devuelve True si la cadena comienza con el valor especificado

#metodo endswith

termina_con_mundo = cadena1.endswith("mundo")#devuelve True si la cadena termina con el valor especificado

#metodo replace

nueva_cadena = cadena1.replace("mundo", "python")#reemplaza una subcadena por otra y si  no se encuentra no hace nada

#print(nueva_cadena)  #devuelve "hola python"

#metodo split

lista_palabras = cadena1.split(" ")#divide la cadena en una lista de subcadenas segun el separador especificado

#print(lista_palabras) #devuelve ['hola', 'mundo']