def frase(nombre,apellido,abjetivo):
    return f"hola {abjetivo},{nombre} tu apellido es {apellido} "
datos = frase("luis","moina","hombre")
print(datos)

#   podemos forsar el argumento (keyword arguments)
datos2 = frase(abjetivo="hombre",nombre="luis",apellido="moina")# necesiaramen se tiene que forsar todos los argumentos 
print(datos2)

#podemos forsar que un parametro tenga un dato 
def datos2(nombre,apellido,abjetivo= "mujer" ):
    return f"hola {abjetivo}, {nombre} tu apellido es {apellido} no ?"

datos3 =datos2("luis","moina")#n es necesiaro poder el argumento de abjetivo ya que ya tiene un dator
datos4 = datos2("luis","moina",abjetivo = "hombre")#pero igualmente que el anterior podemos forzarlo
print(datos4)