

#enocrnterando el numero mayor y menor de una lista
lista= [12,26,18 ]
numero_max = max(lista)#nos devuebe el numeor mayor
numeor_min= min(lista)#nos devuelve el numero minimo


#redondeando al 6 decimales
#se puede redondear con la funcion round 
#podemos elegir hasta cuantos dijtos rendondee 

numero = round(12.34,1) #dependiendo de si es 1 solo va un deciaml

#siguiente funion retornan false -> 0 ,vacio= cuando la lista esta vacia entre otros  ,false, none
#y nos debuelve true si es una cadena, lista ,entrre otros
resultado_boleano = bool(["luis","moina"]) 

#esta funcion retorna true ,si todos los valores son verdaderos


resultado_all = all([21,"luis"])

#suma todos los datos de un iterable 
suma_total = sum(lista)












print(suma_total)