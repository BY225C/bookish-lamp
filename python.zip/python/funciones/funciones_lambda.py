numeros= [1,2,3,4,5,6,7,8,9]
#la funcion lambda

multiliaccion_por_dos= lambda x : x*2 

#es lo mismo que 
#def multiplicacion_por_dos(x):
 #   return x*2

#creando una funcion para ver cuales son numeros pares 
#def es_par(par):
 #   if (par%2==0):
  #      return True 
#usando lla funcion filter lo que hae es filtrar todos los datos en una lista }
#datos_pares = filter(es_par,numeros)#al poner los numeros es darle a la funio  par los para,etros de los la lista numeros 
 #nos dar filter ya que los filtro para ver los datos es
#print(list(datos_pares))


# creando lo mismo pero con lambda
par = filter(lambda numero:numero%2==0,numeros)
print(par)
print(list(par))
