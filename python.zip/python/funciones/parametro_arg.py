#forma no optima de sumar varios valores
#def suma(lista):
    #numeros_sumados= 0
   # for numero in lista :
  #      numeros_sumados = numeros_sumados + numero
 #   return numeros_sumados 




#resultado=suma([2,9,2])
#print(resultado)

#forma mejor con el pparametro arg
# peoro el poblemo de este parametro es que el siguiente parametro no se va ejevutar ejm
#def suma(nombre,*numeros,edad(este parametro no se va ejecutar ya qie el parametor arg es infinito))

def suma(*numeros): # lo ue hace * es el unir todos los valores en uno solo
    return sum(numeros)

resultado=suma(12,219,1)
print(resultado)

#lo mismo que arriba pero usando el parametro arg en el argumetro 
def sum5(listaa): 
    return sum([*listaa])


resultdo1=sum5([12,219,12])
print(resultdo1)

