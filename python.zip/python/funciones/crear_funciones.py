#ussamos de para crear nuentra funcion
#creando una funcion dimple


#def saludar () :
#    print("hola luis")
    
#saludar ()

#creando una funcion con parametro
#depende que pogamos dentro de la funcion te camabiara el dato del nombre

def saludar (nombre,sexo):
    sexo = sexo.lower() #ya que lower convierte la cadena en minusculas y el texto que es Hombre con hombre no va avariar
    if (sexo == "mujer"):
        abjetivo = "maestra"
    elif (sexo == "hombre"):
        abjetivo = "maestro"
    else :
        abjetivo ="nose"     


    print(f"hola {nombre},{abjetivo} como estas")


saludar("luis","Hombre")#podemos cambiar el nombre y agregar mas interpretaciones

#crear una funcion que nos retorne valores7
#la consola lee mi codojo como hago para que yo solo lo lea 

#creando un afuncio que nos retorna varias variables 
def contraseña_r(num):
    caracteres ="asnjsajnjas"
    num_entero=str(num)
    num = int(num_entero[0])
    c1 = num -2
    c2 = num -1
    c3 = num -4
    contraseña = f"{caracteres[c1]}{caracteres[c2]}{caracteres[c3]}{num*2}"
    return contraseña,num #lo que hace es no mostrar la contraseña en la terminan

#para mdesempaquetar las variables
contraseña1,primer_dijito = contraseña_r(12)
#ejecutando las variables 
print(primer_dijito)
print(contraseña1)


