a = 3
b = 5
#son variables porque pueden poder cambiar su valor

nombre = "LUIS"#se puedes editar el valor de la variables

print(nombre)

numero=10
numero+=1
print(numero)#se suman los numeros

#tambien estan los fstring que son cadenas de texto que permiten incluir variables dentro del texto
edad= "15"
edad_mensaje=f"hola tengo {edad} años"
# del edad_mensaje  #elimina la variable
print(edad_mensaje)

print("hola" in edad_mensaje)#verifica si "hola" esta en la variable edad_mensaje y devuelve True o False

#el camelCase es una convención de nomenclatura en la que las palabras se unen sin espacios y cada palabra comienza con una letra mayúscula, excepto la primera palabra. Por ejemplo: miVariableEjemplo.
miVariableEjemplo = "esto es un ejemplo de camelCase"

#el snake_case es una convención de nomenclatura en la que las palabras se unen con guiones bajos (_) y todas las letras están en minúsculas. Por ejemplo: mi_variable_ejemplo.
mi_variable_ejemplo = "esto es un ejemplo de snake_case"

