



#la lista de animales

lista_animales= ["perro","gato","loro","mono"]

for animales in lista_animales:
    print(animales)

#iterarndo com umeors y multiplicando con 10

numeros1 =[2, 23,25,76]

for numeros in numeros1:
    multiplicacion_por_diez= numeros*10
    print(multiplicacion_por_diez)

#iterando con listas
#para iterara con dos listas se hace con la funcion zip
for numeros,animales in zip(numeros1,lista_animales):
    print(f"ese animal es {animales} y su numero es {numeros}")



#iterar con la funcion con la funcon range
#itera segun de numero 1al 2

for numer in range(5,12):#coloca desde el numero que iniciamos hasta el ultimo numeor menos uno
    #sin embargo cuando solo es un solo un numero empieza desde el cero hasta el numero que colocamos -1
    print(numer)



#se puede correr un la lista con range pero de una forma no optima 

for numer in range(len(numeros1)):#ya uqe len se encarga de ver la cantidad de datos que hay en la lista
    print(numeros1[numer])


#forma correcta para correr una lista segun su idice con enumerate que hace es el haces tuplas segun el orden de los datos de la lista 

for num in enumerate(numeros1):#podemos ver el valos con 1 y con 0 para el indice dentro de []
    indice= num[0]
    numero= num [1]
    print(f"el indice es {indice} y su numero es {numero}")

#usando el else
#el else se pone al nivel de for 
for numer in numeros1:
    print(f"estos numeros son variados {numer}")
else:
    print("se acabo el bucle")

#todo funciona tambien para las tuplas




    