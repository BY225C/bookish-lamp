#el while ejecuta infinitamente hasta que la condision se complete que seria ser mayor o igual a 10
#creando un contador que se va ir sumando
contador = 1
while contador <= 10:
  contador += 1 
  print(contador)