lista= ["luis","moina","chuctaya"]
cadena = "Hola Luis"
numeros = [2,36,29]


#lo que hace continue es el saltarse el dato que ponemos 
for apellidos in lista:
    if apellidos== "luis":
        continue
    print(apellidos)

#terminando un bucle con el termino break si los ponemmos despues de print lo que pasa es el datos cuando se ejecute pare s ahi 
# sin embargo cuando lo ponemos antes del prin sno se ejecuta 
for apellidos in lista :
    print(apellidos)
    if apellidos == "moina":   
     break#igual no ejecuta el else
else :
   print("terminamos con el bucle")

#recorrer una cade de texto
#cuando recorre una cadena recorre por dijitos
for letra in cadena :
   print(letra)

#for en una sola linea de codijo

#numerospordos = list()
#for numero in numeros :
 #  numerospordos.append(numero*2) 
   
#forma mejor 
numeros_duplicados= [x*2 for x in numeros]
print(numeros_duplicados)

