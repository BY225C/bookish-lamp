diccionario = {
    "nombre":"luis",
    "apellido":"moina",
    "edad" : 15
}

#siempre va poner las keys 
for key in diccionario :
    print(key)
#mientras si poneos .items() nos va a poner los items como tupla calve y valor

for items in diccionario.items():
    print(items)
#('nombre', 'luis')
#('apellido', 'moina')
#('edad', 15)
#podemos separaralo com anterior mente con los conjuntos y las lista y las tuplas

for datos in diccionario.items(): #segun asiganmos 0 nos dara la key y si ponemos 1 nos dara los items
    llaves = datos[0]
    valor = datos[1]
    print(f"el valor es {valor} y su llave es {llaves}")
else :
    print("terminamos de hablar de los datos ")





