#la conjuntos de animales

conjuntos_animales= {"perro","gato","loro","mono"}

for animales in conjuntos_animales:
    print(animales)

#iterarndo com umeors y multiplicando con 10

numeros1 ={2, 23,25,76}

for numeros in numeros1:
    multiplicacion_por_diez= numeros*10
    print(multiplicacion_por_diez)

#iterando con conjuntoss
#para iterara con dos conjuntoss se hace con la funcion zip
for numeros,animales in zip(numeros1,conjuntos_animales):
    print(f"ese animal es {animales} y su numero es {numeros}")



#iterar con la funcion con la funcon range
#itera segun de numero 1al 2

for numer in range(5,10):#coloca desde el numero que iniciamos hasta el ultimo numeor menos uno
    #sin embargo cuando solo es un solo un numero empieza desde el cero hasta el numero que colocamos -1
    print(numer)



#forma correcta para correr una conjuntos segun su idice con enumerate que hace es el haces tuplas segun el orden de los datos de la conjuntos 

for num in enumerate(numeros1):#podemos ver el valos con 1 y con 0 para el indice dentro de {}
    indice= num[0]
    numero= num [1]
    print(f"el indice es {indice} y su numero es {numero}")

#usando el else
#el else se pone al nivel de for 
for numer in numeros1:
    print(f"estos numeros son variados {numer}")
else:
    print("se acabo el bucle")

#se iterar con los conjuntos pero nose iterar co range
