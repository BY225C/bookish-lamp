#los operadores de comparcion son los simbolos que utilizamos para comparar valores 
#los operadores de comparacion son:
#igualdad ==
#diferencia !=
#menor que <
#menor o igual que <=
#mayor que >
#mayor o igual que >=
# devuelven un valor booleano (True o False)
igualdad= 3 == 5
diferencia= 3 != 5
menor_que= 3 < 5
menor_o_igual_que= 3 <= 5
mayor_que= 3 > 5
mayor_o_igual_que= 3 >= 5
print(igualdad) #False
print(diferencia) #True
print(menor_que) #True
print(menor_o_igual_que) #True
print(mayor_que) #False
print(mayor_o_igual_que) #False

#calculo combinado

a=1
b=2
c=3

comparacion = a + b == c

print(comparacion)#true ya que si son iguales

#comparar ususarios
usuario_ingresado = "luis"
usuario_bd = "admin"
es_admin = usuario_ingresado == usuario_bd
print(es_admin) #false ya que no son iguales