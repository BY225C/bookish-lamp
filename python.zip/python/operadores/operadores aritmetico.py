#los operadores aritmeticos son los simbolos que se utilizan para realizar operaciones matematicas basicas
#los operadores aritmeticos son:
#suma +
#resta -
suma= 3 + 5
resta= 5-4

#multiplicacion *
#division /
multiplicacion= 4 * 2
division= 10 / 2

#division entera //
division_entera= 10 // 3 # la divicion lo redondea al numero mas cercano  sin decimales 

#modulo %  te da el residuo 
modulo= 10 % 3

#potencia **
potencia= 2 ** 3

print(suma)
print(resta)
print(multiplicacion)
print(division)
print(division_entera)
print(modulo)
print(potencia)

type_modulo= type(modulo)#devuelve el tipo de dato de la variable
print(type_modulo)