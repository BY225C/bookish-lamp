#los operadores logicos son los simbolos que se utilizan para combinar expresiones booleanas
#los operadores logicos son:
#AND son & 
and_resultado= True & False #devuelve False si alguna de las dos expresiones es False
#OR son |
or_resultado= True | False #devuelve True si alguna de las dos expresiones es True
#NOT es ! o not 
not_resultado= not True #devuelve el valor contrario de la expresion

print(and_resultado) #False
print(or_resultado) #True
print(not_resultado) #False
