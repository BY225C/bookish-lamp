"string"#es un texto
"int"#es numero entero
"float"#es numero decimal
"bool"#es un valor logico (True o False)
"list"#es una lista de elementos}
"str"#es texto

