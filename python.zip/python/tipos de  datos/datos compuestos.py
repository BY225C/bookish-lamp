#son datos que tiienen otros datos
lista = ["luis","15","Lumod",False,1.65] #la lista se crea con corchetes []
print(lista[0])  
#colocamos alado un [] para ver el dato y se organiza desde 0 1 2 3 4 

lista[0]="carlos" #modificamos el primer valor de la lista
print(lista[0])

#creando una tupla
tupla=("luis","15","Lumod",False,1.65) #la tupla se crea con parentesis () y nose puede modifcar


# pero con tupla mno se puede hacer eso
#tupla[0]="carlos" #esto dara error porque no se puede modificar una tupla


#creando un conjunto (set)

conjunto={"luis","15","Lumod",False,1.65} #el conjunto se crea con llaves {}
#el conjunto se puede modificar pero no se puede acceder a un valor en especifico porque no tiene un orden y aceeder a un valor por su indice
#y tampoco permite valores duplicados

#creando un diccionario (dict)
diccionario={
    "nombre": "luis",
    "edad":15,
    "estatura":1.65,
    "esta_feliz":True,
    "dato duplicado": "luis"#los diccionarios si permiten valores duplicados pero no claves duplicadas
}
print(diccionario["nombre"])#se accede al dato con el nombre
