#if-else
edad = 15

if edad >= 18:
    print("si puedes pasar ")
else:
    print("no puedes pasar")

#otro ejemplo

contraseña="luis123"
contraseña_escrita="luis123"

if contraseña == contraseña_escrita:
    print("contraseña correcta")
else:
    print("contraseña incorrecta")


#else-if 
#elif se utiliza para evaluar multiples condiciones

nota= 17

if nota == 20:
    print("exelente")
elif nota >= 16:#podemos colocar varios elif
    print("esta bien")
else:
    print("reprobado")

#tambien podemos usar otro if dentro de un if

nota2= 20
puntos=-5

if nota2 == 20:
    if nota2 + puntos >= 20:
        print("estas bien")
    else:
        print("bajaste de nota")    
elif nota2 >= 16:#podemos colocar varios elif
    print("esta bien")
else:
    print("reprobado")


