#creando un conjunto con set 
conjunto = set(["luis","moina"])# se puede colocar un atupla dentro ya que no se puede modificar

#crenado un conjunto dentro de otro conjunto
conjunto1= frozenset(["1","2"]) # se puede meter una conjuto dentro de otro conjunto 
#mediante la funcion frozenset pero sin la funcion sale error
conjunto2 ={ conjunto1 ,"3"}

#teoria de conjuntos

#se puede verificar cual es subconjunto y superconjunto de cada uno
conjunto3 = {1,2,3}
conjunto4 = {1,2,3,4,5,6}

resultado= conjunto3.issubset(conjunto4)#lo que hace issubset es ver si el conjunto 3 es subconjunto de conjunto 4 
resultado1 = conjunto3 <= conjunto4 #otro metodo es el coloar <= yaque dice es menor o igual que yaque el conjunto3 es meor quw el conjuno4

resultado2 = conjunto4.issuperset(conjunto3)#loque hace issuperset es verificar que conjuto4 es el superconjunto de conjunto3
resultado3 = conjunto4 > conjunto3 # este metodo verifica que conjunto4 es mayor que el enconjunto3 ya que > dice si es mayor que


print(resultado3)