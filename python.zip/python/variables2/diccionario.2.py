#se puede crear un diccionaio con dict
diccionario = dict(nombre="luis",apellido="moina",edad=15)

#las tuplas tambien pueden ser claves ejm:
diccionario_con_tupla = {("luis","moina","15"):"caracteristicas de luis"}

#creando diccionarios con fromkeys 
diccionario1 = dict.fromkeys("luis","moina") #al ejecutarlo cada dijito sera la clave y moina es su datosy lo itera
diccionario2 = dict.fromkeys(["luis","moina"])#colocando las llaves se colocan como datos y su clave seria none

 
print()





