
#creando tuplas con tuple 

tupla = tuple(["luis","moina",15]) #necesiaramente se coloca [] dentro del parentisis para se conbierta nen una tupla


#se pude crear una tupla sin parentisis

tupla1 = "luis", #se puede crear una tupla de un solo elemento


print(type(tupla1))
print(type(tupla))

