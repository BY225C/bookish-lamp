#podemos asignar variables con datos de listas , tuplas entre otros

#aignamos las variables segun el orden de las varibles se pude con listas y tuplas 
datos = {"luis","moina",15} 
nombre,apellido,edad = datos

print(edad)