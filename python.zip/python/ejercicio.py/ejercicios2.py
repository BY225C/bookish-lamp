#falto el profesor y los estudiantes van sustituir 
 #hay que pedir los daros de los d¿estudiates y de los profesor
def cantidad_de_compañeros(cantidad_de_compañeros):
    compañeros=[]
    #ejecutando un for para pedir la informacio de los estudiantes
    for i in range(cantidad_de_compañeros):
       nombre = input("ingrese el nombre de los estudiantes y profesores")
       edad = int(input("ingrese la edad de los estudiantes"))
       compañero=(nombre,edad)
       #agregando informacion con el metodo append 
       compañeros.append(compañero)
       #ordenando de menor a mayor con el metodo sort y usando la key y lambda para ordenar segun la edad
    compañeros.sort(key=lambda x:x[1])
    #eligindo al profesor y al assistente con tuplas que eligen el valr de la edad 
    asistente= compañeros[0][0]
    profesor= compañeros[-1][0]
    #retornamos las tuplas
    return asistente,profesor

#desempaquetamos lo que nos retorna la fucion
asistente,profesor=cantidad_de_compañeros(8)
print(f"el profeso es {profesor} y su assistente {asistente}")






