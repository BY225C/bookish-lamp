#haciendo una funcion que me de la serie fibonacci hasta el numero
#que pusimos


def serie_fibonaci(num):
    lista =[]
    a,b = 0,1
    for i in range(num):
        if b > num: return lista
        else :
            lista.append(b)
            a,b = b,a+b


resultado = serie_fibonaci(33)
print(resultado)