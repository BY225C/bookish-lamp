#creando una funcion que me los numeros primos

#crear una funcion que verifique que el numero es primo 
def numero_primo (num):
    #colocamos un bucle que verifique que el numeor no se pueda dividir
    # por ningun numero entre y el mismo numero -1 
    for i in range(2,num-1):
        #si alguno nose divide retornamos true y si no es retonamos false
        if num/i == 0:return False
    return True 
#creamos una funcion donde nos de los numeros primos 
def primos_hasta(num):
    #creamos una lista para que se gyarden los datos de los numeros
    primos=[]
    #colocamos un rango de los numeros primos y desde el 3 y lo sumamos +1 para que tome el mismo numero si es primo
    for i in range(3,num+1):
        #en caso que sea primo seguimos 
        resultado = numero_primo(i)
        if resultado == True: 
            #y lo agregamos a la lista
            primos.append(i)
            #y retornamos primos la lista
    return primos       



resultado_si_es_primo = numero_primo(3)#nos da true
lista_de_numeros_primos= primos_hasta(5)#nos da [3,4,5]

print(lista_de_numeros_primos)
print(resultado_si_es_primo)




