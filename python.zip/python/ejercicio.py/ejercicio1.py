
#promedios de duracion
otros_cursos_min = 2.5
otros_cursos_max = 7
otros_cursos_promedio = 4
curso_d = 1.5
# duracion de crudos
crudos_promedio = 5
crudos_de_d = 3.5

#calculando la diferencia del tiempo vacio

print("----------------------------------------")
tiempo_promedio_vacio = 100 - otros_cursos_promedio*1000 // crudos_promedio /10
tiempo_vacio_d = 100 - curso_d *1000 // crudos_de_d /10

print(tiempo_promedio_vacio)
print(tiempo_vacio_d)

#diferencias de duracion

print("----------------------------------------")
diferencia_min = 100 - curso_d / otros_cursos_min *100
difencia_max = 100 - curso_d * 1000 // otros_cursos_max/10 
diferencia_promedio = 100 - curso_d / otros_cursos_promedio*100

print(f"el curso de d es un {diferencia_min} menos de los demas cursos")
print(f"el curso de d es un {difencia_max} mas de los demas cursos")                                                         
print(f"el curso de d es un {diferencia_promedio}  de los demas cursos")
print("----------------------------------------")

#mostrando diferencias entre las diez horas 
print(f"ver diez horas del curso d se equipara a ver {otros_cursos_promedio *100// curso_d/10 }% de otros cursos")

print("----------------------------------------")


#segundo ejercio 

frase = input("dime algo y te digo cunto tardarias: ")

cantidad_de_palabras= frase.split( )

cantidad_de_dijitos_de_la_palabra = len(cantidad_de_palabras)

print(f"dijiste {cantidad_de_dijitos_de_la_palabra} palabras y tardarias {cantidad_de_dijitos_de_la_palabra/2} segundos en decirlo ")

if cantidad_de_dijitos_de_la_palabra > 120 : 
    print("espera estas hablando mucho")